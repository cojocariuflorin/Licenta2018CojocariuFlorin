<?php

use Illuminate\Support\Facades\Route;
Route::post('/login', 'UsersController@login');
Route::post('/admin', 'UsersController@adminLogin');
Route::get('/verify/{chairId}/{confirmation_token}', 'UsersController@verify');

Route::resource('stations', 'StationsController')->only(['index', 'show']);
Route::group(['middleware' => 'auth:api'], function()
{
    Route::get('/me','UsersController@showCurrentUser');
    Route::get('/orderUser', 'UsersController@getOrderForCurrentUser');
    Route::get('/pay', 'UsersController@payForCurrentUser');
    Route::get('/orderTable', 'UsersController@getOrdersForCurrentTable');
    Route::get('/payForTable', 'UsersController@payForTable');
    Route::resource('categories', 'CategoriesController', ['parameters' => ['categories' => 'category']])->only(['index','show']);
    Route::resource('menus', 'MenusController', ['parameters' => ['menus' => 'menu']])->only(['show']);
    Route::resource('products', 'ProductsController')->only(['index', 'show', 'store','destroy']);
    Route::post('/products/{product}', 'ProductsController@update');
    Route::resource('allergens', 'AllergensController')->only(['index']);
    Route::resource('orders', 'OrdersController')->only(['index', 'show', 'store', 'update']);
    Route::put('/logout', 'UsersController@logout');
});

