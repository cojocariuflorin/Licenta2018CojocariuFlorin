<?php
/**
 * Created by PhpStorm.
 * User: Florin Cojocariu
 * Date: 16-May-18
 * Time: 20:25
 */

namespace App\Repositories;


use App\Allergen;
use App\Http\Requests\ProductRequest;
use App\Http\Requests\ProductUpdateRequest;
use App\Product;
use App\ProductsPhoto;
use Illuminate\Support\Facades\Storage;

class ProductRepository
{
    protected $model;

    public function __construct(Product $product)
    {
        $this->model = $product;
    }

    public function index()
    {
        return $this->model->all()->load('allergens', 'photos');
    }

    public function show($id)
    {
        return $this->model->findOrFail($id);
    }

    public function store(ProductRequest $request)
    {
        $this->model->name = $request->input('name');
        $this->model->ingredients = $request->input('ingredients');
        $this->model->category_id = $request->input('category_id');
        $this->model->price = $request->input('price');
        $this->model->save();

        $filename = $request->photo->store('products/photos');
        ProductsPhoto::create([
            'product_id' => $this->model->id,
            'filename' => $filename
        ]);
        if ($request->has('allergens')) {
            $allergens = $request->input('allergens');
            foreach ($allergens as $allergen) {
                $allergen = Allergen::where('name', $allergen)->get();
                $this->model->allergens()->attach($allergen);
            }
        }
        return $this->model;
    }

    public function update(ProductUpdateRequest $request, $id)
    {
        $product = $this->model->find($id);

        $product->name = $request->input('name');
        $product->ingredients = $request->input('ingredients');
        $product->price = $request->input('price');
        if ($request->hasFile('photo')) {
            $photos = $product->photos;
            foreach($photos as $photo)
                Storage::delete($photo->filename);
            $filename = $request->photo->store('products/photos');
            $productPhoto = ProductsPhoto::find($product->id);
            $productPhoto->update(['filename' => $filename]);
        }

        $product->allergens()->detach();
        $product->save();
        if ($request->has('allergens')) {
            $allergens = $request->input('allergens');
            foreach ($allergens as $allergen) {
                $allergen = Allergen::where('name', $allergen)->get();
                $product->allergens()->attach($allergen);
            }
        }
        return $product;
    }

    public function delete(Product $product)
    {
        $deleted = $product;
        $product->delete();
        return $deleted;
    }
}