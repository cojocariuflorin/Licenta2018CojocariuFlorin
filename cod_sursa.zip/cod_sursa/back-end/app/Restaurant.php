<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Restaurant extends Model
{
    public function menu()
    {
        return $this->hasOne(Menu::class);
    }
}
