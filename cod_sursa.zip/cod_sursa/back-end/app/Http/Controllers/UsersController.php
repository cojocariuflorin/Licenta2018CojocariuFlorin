<?php

namespace App\Http\Controllers;

use App\Http\Requests\AdminLoginRequest;
use App\Http\Requests\UserRequest;
use App\Mail\ConfirmationEmail;
use App\Order;
use App\User;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class UsersController extends Controller
{
    public function login(UserRequest $request)
    {
        $user = User::where('email', $request->input('email'))->first();
        if (!$user) {
            $name = explode('@', $request->input('email'))[0];
            $user = User::create([
                'name' => $name,
                'email' => $request->input('email'),
                'confirmation_token' => str_random('30') . time(),
            ]);
        } else {
            $user->confirmation_token = str_random('30') . time();
            $user->save();
        }
        $chair_id = $request->input('chair_id');
        Mail::to($user)->send(new ConfirmationEmail($chair_id, $user->confirmation_token));
        return response()->json([
            'data' => $user,
            'errors' => null,
            'status' => Response::HTTP_CREATED,
        ], Response::HTTP_CREATED);
    }

    public function verify($chairId, $confirmation_token)
    {
        $user = User::where('confirmation_token', $confirmation_token)->first();
        if ($user) {
            $user->confirmation_token = null;
            $user->chair_id = $chairId;
            $user->save();
            Auth::login($user);
            $logedInUser = Auth::user();
            $success['token'] = $logedInUser->createToken('Orderino')->accessToken;
            return response()->json([
                'data' => $success,
                'errors' => null,
                'status' => Response::HTTP_OK,
            ], Response::HTTP_OK);
        } else {
            return response()->json([
                'data' => null,
                'error' => 'Unauthorized',
                'status' => Response::HTTP_UNAUTHORIZED,
            ], Response::HTTP_UNAUTHORIZED);
        }
    }

    public function adminLogin(AdminLoginRequest $request)
    {
        if (Auth::attempt(['email' => $request->input('email'), 'password' => $request->input('password')])) {
            $user = Auth::user();
            $success['token'] = $user->createToken('Orderino')->accessToken;
            return response()->json([
                'data' => $success,
                'errors' => null,
                'status' => Response::HTTP_OK,
            ], Response::HTTP_OK);
        } else {
            return response()->json([
                'data' => null,
                'errors' => 'Invalid credentials',
                'status' => Response::HTTP_UNAUTHORIZED],
                Response::HTTP_UNAUTHORIZED);
        }
    }

    public function logout()
    {
        $user = User::find(Auth::user()->id);
        $user->chair_id = null;
        $user->save();
        return response()->json([
            'data' => $user,
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }

    public function getOrderForCurrentUser()
    {
        $user = Auth::user();
        $ordersForUser = Order::where('user_id', $user->id)->where('status', 'like', '%' . 'delivered' . '%')->with('product')->get();
        $price = 0;
        foreach ($ordersForUser as $order) {
            $price = $price + $order->product->price;
        }
        $price = number_format((double)$price, 2, '.', '');
        return response()->json([
            'data' => $ordersForUser,
            'errors' => null,
            'status' => Response::HTTP_OK,
            'total_price' => $price
        ], Response::HTTP_OK);
    }

    public function payForCurrentUser()
    {
        $user = Auth::user();
        $ordersForUser = Order::where('user_id', $user->id)->where('status', 'like', '%' . 'delivered' . '%')->with('product')->get();
        $price = 0;
        foreach ($ordersForUser as $order) {
            $price = $price + $order->product->price;
        }
        $price = number_format((double)$price, 2, '.', '');
        if ($user->credit - $price <= 1)
            return response()->json([
                'data' => null,
                'errors' => "You don't have enought credit to pay the bill!",
                'status' => Response::HTTP_UNPROCESSABLE_ENTITY,
            ], Response::HTTP_UNPROCESSABLE_ENTITY);
        $user->credit = $user->credit - $price;
        $user->chair_id = null;
        $user->save();
        $ordersForUser = Order::where('user_id', $user->id)->where('status', 'like', '%' . 'delivered' . '%')->get();
        foreach ($ordersForUser as $order) {
            $order->status = 'payed';
            $order->save();
        }
        return response()->json([
            'data' => $user,
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }

    public function getOrdersForCurrentTable()
    {
        $user = Auth::user();
        $station = $user->chair->station;
        $chairs = $station->chairs;
        $sum=0;
        $ordersForUser = [];
        foreach($chairs as $chair){
            if($chair->user)
            {
                $ordersForUser[$chair->user->name]['orders'] = Order::where('user_id', $chair->user->id)
                    ->where('status', 'like', '%' . 'delivered' . '%')->with('product')
                ->get();
                $price = 0;
                foreach ($ordersForUser[$chair->user->name]['orders'] as $order) {
                    $price = $price + $order->product->price;
                }
                $price = number_format((double)$price, 2, '.', '');
                $ordersForUser[$chair->user->name]['total_price'] = $price;
               $sum += $price;
            }
        }

        return response()->json([
            'data' => $ordersForUser,
            'total_price' => $sum,
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }
    public function payForTable()
    {
        $user = Auth::user();
        $station = $user->chair->station;
        $chairs = $station->chairs;
        $sum = 0;
        $ordersForUser = [];
        foreach($chairs as $chair){
            if($chair->user)
            {
                $ordersForUser[$chair->user->name]['orders'] = Order::where('user_id', $chair->user->id)
                    ->where('status', 'like', '%' . 'delivered' . '%')->with('product')
                    ->get();
                $price = 0;
                foreach ($ordersForUser[$chair->user->name]['orders'] as $order) {

                    $price = $price + $order->product->price;

                }
                $price = number_format((double)$price, 2, '.', '');
                $ordersForUser[$chair->user->name]['total_price'] = $price;
                $sum += $price;
            }
        }
        if ($user->credit - $sum <= 1)
            return response()->json([
                'data' => null,
                'errors' => "You don't have enought credit to pay the bill!",
                'status' => Response::HTTP_UNPROCESSABLE_ENTITY,
            ], Response::HTTP_UNPROCESSABLE_ENTITY);
        $user->credit = $user->credit - $sum;
        $user->chair_id = null;
        $user->save();

        foreach($chairs as $chair){
            if($chair->user) {
                $ordersForUser = Order::where('user_id', $chair->user->id)
                    ->where('status', 'like', '%' . 'delivered' . '%')->with('product')
                    ->get();
                foreach ($ordersForUser as $order) {
                    $order->status = 'payed';
                    $order->save();
                }
            }
        }
        return response()->json([
            'data' => $user,
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);


    }

    public function showCurrentUser()
    {
        $user = Auth::user();
        $return = User::where('id', $user->id)->first();
        return response()->json([
           'data' => $return,
           'errors' => null,
           'status' => Response::HTTP_OK,
        ],Response::HTTP_OK);

    }
}
