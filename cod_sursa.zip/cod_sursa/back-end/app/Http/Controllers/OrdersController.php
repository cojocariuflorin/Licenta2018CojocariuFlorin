<?php

namespace App\Http\Controllers;

use App\Http\Requests\OrderRequest;
use App\Order;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class OrdersController extends Controller
{

    public function index()
    {
        $orders = Order::all();
        return response()->json([
           'data' => $orders->load([
               'product' => function ($query) {
                    $query->withTrashed();
               },
               'user'
           ]),
            'error' => null,
            'status' => Response::HTTP_OK
        ],Response::HTTP_OK);
    }


    public function store(OrderRequest $request)
    {
        $product = $request->input('product_id');
        $user = Auth::user();
        if($user)
            $order = Order::create([
                'product_id' => $product,
                'user_id' => $user->id
            ]);
        return response()->json([
            'data' => $order,
            'errors' => null,
            'status' => Response::HTTP_OK
        ], Response::HTTP_OK);
    }


    public function show($id)
    {
        $order = Order::find($id);
        return response()->json([
            'data' => $order,
            'errors' => null,
            'status' => Response::HTTP_OK
        ], Response::HTTP_OK);
    }


    public function update(Request $request, $order)
    {
        $order = Order::find($order);
        $order->status = $request->input('status');
        $order->save();
        return response()->json([
            'data' => $order,
            'errors' => null,
            'status' => Response::HTTP_OK
        ], Response::HTTP_OK);
    }

}
