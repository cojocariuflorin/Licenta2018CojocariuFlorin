<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductRequest;
use App\Http\Requests\ProductUpdateRequest;
use App\Product;
use App\Repositories\ProductRepository;
use Illuminate\Http\Response;

class ProductsController extends Controller
{
    protected $productRepository;

    public function __construct(ProductRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    public function index()
    {
        $products = $this->productRepository->index();
        return response()->json([
            'data' => $products,
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }

    public function show(Product $product)
    {
        return response()->json([
            'data' => $product->load('allergens', 'photos'),
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }

    public function store(ProductRequest $request)
    {
        $product = $this->productRepository->store($request);

        return response()->json([
            'data' => $product,
            'errors' => null,
            'status' => Response::HTTP_CREATED,
        ], Response::HTTP_CREATED);
    }

    public function update(ProductUpdateRequest $request, $product)
    {
        $product = $this->productRepository->update($request, $product);

        return response()->json([
            'data' => $product,
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }

    public function destroy(Product $product)
    {
        $deleted = $this->productRepository->delete($product);

        return response()->json([
            'data' => $deleted,
            'errors' => null,
            'status' => Response::HTTP_OK
        ], Response::HTTP_OK);
    }
}
