<?php

namespace App\Http\Controllers;


use App\Category;
use Illuminate\Http\Response;

class CategoriesController extends Controller
{
    public function index()
    {
        $categories = Category::all()->load('products.photos', 'products.allergens');
        return response()->json([
            'data' => $categories,
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }

    public function show(Category $category)
    {
        return response()->json([
            'data' => $category->load('products.photos', 'products.allergens'),
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }
}
