<?php

namespace App\Http\Controllers;

use App\Station;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class StationsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stations = Station::all();
        return response()->json([
            'data' => $stations->load('chairs.user'),
            'errors' => null,
            'status' => Response::HTTP_OK,
        ], Response::HTTP_OK);
    }


}
