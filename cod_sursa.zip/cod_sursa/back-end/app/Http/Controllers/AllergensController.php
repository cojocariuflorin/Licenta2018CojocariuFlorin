<?php

namespace App\Http\Controllers;

use App\Allergen;
use Illuminate\Http\Response;


class AllergensController extends Controller
{
    public function index()
    {
        return response()->json([
            'data' => Allergen::all(),
            'errors' => null,
            'status' => Response::HTTP_OK
        ],Response::HTTP_OK);
    }
}
