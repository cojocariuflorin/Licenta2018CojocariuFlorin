<?php

namespace App\Http\Controllers;

use App\Http\Resources\Menu\MenuCollection;
use App\Menu;
use App\Repositories\MenuRepository;
use Illuminate\Http\Response;

class MenusController extends Controller
{

    public function show(Menu $menu)
    {
        return response()->json([
            'data'=>$menu->load('categories.products'),
            'errors' => null,
            'status' => Response::HTTP_OK,
        ],Response::HTTP_OK);
    }

}
