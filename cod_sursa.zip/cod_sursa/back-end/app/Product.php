<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    protected $fillable = ['name', 'ingredients', 'category_id', 'price'];

    public function photos()
    {
        return $this->hasMany(ProductsPhoto::class);
    }

    public function categories()
    {
        return $this->belongsTo(Category::class);
    }

    public function allergens()
    {
        return $this->belongsToMany(Allergen::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }
}
