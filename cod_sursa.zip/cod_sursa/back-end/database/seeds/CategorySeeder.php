<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            'menu_id' => '1',
            'name' => 'Pizza'
        ]);

        DB::table('categories')->insert([
            'menu_id' => '1',
            'name' => 'Salads'
        ]);

        DB::table('categories')->insert([
            'menu_id' => '1',
            'name' => 'Pastas'
        ]);

        DB::table('categories')->insert([
            'menu_id' => '1',
            'name' => 'Fish'
        ]);

        DB::table('categories')->insert([
            'menu_id' => '1',
            'name' => 'Soups'
        ]);

        DB::table('categories')->insert([
            'menu_id' => '1',
            'name' => 'Breakfast'
        ]);

        DB::table('categories')->insert([
            'menu_id' => '1',
            'name' => 'Beverage'
        ]);
    }
}
