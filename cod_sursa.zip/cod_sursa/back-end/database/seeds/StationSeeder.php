<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        DB::table('stations')->insert([
            'name' => 'First Table'
        ]);

        DB::table('stations')->insert([
            'name' => 'Second Table'
        ]);

        DB::table('stations')->insert([
            'name' => 'Third Table'
        ]);

        DB::table('stations')->insert([
            'name' => 'Forth Table'
        ]);

    }
}
