<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AllergenSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('allergens')->insert([
            'name' => 'Eggs'
        ]);
        DB::table('allergens')->insert([
            'name' => 'Peanuts'
        ]);
        DB::table('allergens')->insert([
            'name' => 'Soybeans'
        ]);
        DB::table('allergens')->insert([
            'name' => 'Milk'
        ]);
        DB::table('allergens')->insert([
            'name' => 'Almonds'
        ]);
        DB::table('allergens')->insert([
            'name' => 'Wheat'
        ]);
    }
}
