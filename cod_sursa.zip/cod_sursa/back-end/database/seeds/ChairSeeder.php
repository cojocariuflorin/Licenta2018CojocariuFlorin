<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ChairSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for($i = 1; $i <= 6; $i++)
            DB::table('chairs')->insert([
                'station_id' => 1
            ]);
        for($i = 7; $i <= 12; $i++)
            DB::table('chairs')->insert([
                'station_id' => 2
            ]);
        for($i = 13; $i <= 18; $i++)
            DB::table('chairs')->insert([
                'station_id' => 3
            ]);
        for($i = 19; $i <= 24; $i++)
            DB::table('chairs')->insert([
                'station_id' => 4
            ]);
    }
}
