<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RestaurantSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('restaurants')->insert([
            'name' => 'Orderino',
            'description' => 'You will find a cozy restaurant with classic interior, dominant with calm and warm colors. The restaurant could serve up to 25 persons at the same time. Working hours are from 7:00 AM to 11:00 PM.Breakfast on workdays are form 7:00 AM to 10:30 AM. On weekends from 8:00 AM to 11:00 AM.Those, who are late for breakfast, we invite for a cup of good Italian coffee with a hot cake or to take a replete buffet breakfast. On work days our restaurant offers day lunch from only 7,00 Eur incl. VAT.
In the evening you are welcome to enjoy candle light and calm music. Evening menu will surprise you with low prices and variety of European dishes. The kitchen Sheff cooks only from fresh and carefully selected products.
We are ready to arrange you an unforgettable celebration, restaurant staff will take care about all the smolest details: decorate the hall, arrange musicians, agree the celebration menu with the customer, will make all kinds of world cuisine dishes.'
        ]);
    }
}
