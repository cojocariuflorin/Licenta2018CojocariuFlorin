import 'angular-resource';

let resourceModule = angular.module('app.resources', [
   'ngResource'
]);

export default resourceModule;