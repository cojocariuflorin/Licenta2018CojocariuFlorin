class HomeCtrl {
    constructor() {
    }
}

/* @ngInject */
export default HomeCtrl;