import './home';

let appPages = angular.module('app.pages', [
    'app.home'
]);

export default appPages;