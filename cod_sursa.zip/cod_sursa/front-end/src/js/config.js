const Config = {
  apiEndpoint: 'http://localhost:8000/api',
};

export default Config;