import 'bootstrap';

import 'angular';
import '@uirouter/angularjs';
import '../../bower_components/ng-scrollable/src/ng-scrollable';

import './resources';
import './pages';
import './modules';

import Config from './config';

angular.module('app', [
    'ui.router',
    'app.resources',
    'app.pages',
    'app.modules',
    'ngScrollable'
]);

angular.module('app').config(/* @ngInject */ ($locationProvider, $urlRouterProvider, $qProvider) => {
    // remove # from url
	$locationProvider.html5Mode(true);

    // silence unhandled rejections
    $qProvider.errorOnUnhandledRejections(false);

    // remove ! from url
    $locationProvider.hashPrefix('');

    // default route
    $urlRouterProvider.otherwise(function() {
        return '/';
    });
});

angular.module('app').value('AppConfig', Config);