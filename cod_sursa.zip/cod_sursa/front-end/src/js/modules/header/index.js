let headerModule = angular.module('headerModule', []);

import headerDirective from './header.directive';
headerModule.directive('headerDirective', () => new headerDirective());

import HeaderCtrl from './header.controller';
headerModule.controller('HeaderCtrl', HeaderCtrl);

export default headerModule;