class headerDirective {
    constructor() {
        this.restrict = "EA";
        this.template = require("./header.pug");
        this.controller = "HeaderCtrl";
        this.controllerAs = "$headerCtrl";
    }
}

/* @ngInject */
export default headerDirective;