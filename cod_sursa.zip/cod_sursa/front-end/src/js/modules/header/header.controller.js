class HeaderCtrl {
    constructor() {



    }
}

/* @ngInject */
export default HeaderCtrl;