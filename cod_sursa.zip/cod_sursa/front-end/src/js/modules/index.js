import headerModule from './header';

let modules = angular.module('app.modules', [
    'headerModule'
]);

export default modules;